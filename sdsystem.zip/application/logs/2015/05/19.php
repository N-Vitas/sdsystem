<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-05-19 00:40:38 --- EMERGENCY: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH/classes/Kohana/Cookie.php [ 158 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php:67
2015-05-19 00:40:38 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php(67): Kohana_Cookie::salt('511d13ca51044a3...', NULL)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(151): Kohana_Cookie::get('511d13ca51044a3...')
#2 /home/vitas/www/sdsystem/index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php:67
2015-05-19 00:42:18 --- EMERGENCY: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH/classes/Kohana/Cookie.php [ 158 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php:67
2015-05-19 00:42:18 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php(67): Kohana_Cookie::salt('511d13ca51044a3...', NULL)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(151): Kohana_Cookie::get('511d13ca51044a3...')
#2 /home/vitas/www/sdsystem/index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php:67
2015-05-19 00:42:19 --- EMERGENCY: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH/classes/Kohana/Cookie.php [ 158 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php:67
2015-05-19 00:42:19 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php(67): Kohana_Cookie::salt('511d13ca51044a3...', NULL)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(151): Kohana_Cookie::get('511d13ca51044a3...')
#2 /home/vitas/www/sdsystem/index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Cookie.php:67
2015-05-19 01:12:16 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:16 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(9): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:31 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:31 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(9): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:35 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:35 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(9): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:39 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:39 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(9): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:45 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:12:45 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(9): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:13:56 --- EMERGENCY: View_Exception [ 0 ]: The requested view main could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:13:56 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('main')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('main', NULL)
#2 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(33): Kohana_View::factory('main')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(69): Kohana_Controller_Template->before()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:13:57 --- EMERGENCY: View_Exception [ 0 ]: The requested view main could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:13:57 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('main')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('main', NULL)
#2 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(33): Kohana_View::factory('main')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(69): Kohana_Controller_Template->before()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:14:09 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:14:09 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(10): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:14:10 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:14:10 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(10): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:45 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:45 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(10): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:45 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:45 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(10): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:46 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:46 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(10): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:47 --- EMERGENCY: View_Exception [ 0 ]: The requested view welcome could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:15:47 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('welcome')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('welcome', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(10): Kohana_View::factory('welcome')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 01:16:03 --- EMERGENCY: ErrorException [ 2 ]: Creating default object from empty value ~ APPPATH/classes/Controller/Main.php [ 13 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:16:03 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(13): Kohana_Core::error_handler(2, 'Creating defaul...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:16:05 --- EMERGENCY: ErrorException [ 2 ]: Creating default object from empty value ~ APPPATH/classes/Controller/Main.php [ 13 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:16:05 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(13): Kohana_Core::error_handler(2, 'Creating defaul...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:18:09 --- EMERGENCY: ErrorException [ 2 ]: Creating default object from empty value ~ APPPATH/classes/Controller/Main.php [ 13 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:18:09 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(13): Kohana_Core::error_handler(2, 'Creating defaul...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:18:10 --- EMERGENCY: ErrorException [ 2 ]: Creating default object from empty value ~ APPPATH/classes/Controller/Main.php [ 13 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:18:10 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(13): Kohana_Core::error_handler(2, 'Creating defaul...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:13
2015-05-19 01:40:28 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '=' ~ APPPATH/views/my_template.php [ 1 ] in file:line
2015-05-19 01:40:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 02:23:29 --- EMERGENCY: View_Exception [ 0 ]: The requested view menu could not be found ~ SYSPATH/classes/Kohana/View.php [ 265 ] in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 02:23:29 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(145): Kohana_View->set_filename('menu')
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(30): Kohana_View->__construct('menu', NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Common.php(12): Kohana_View::factory('menu')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(69): Controller_Common->before()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/View.php:145
2015-05-19 02:27:32 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left_menu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:27:32 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:36 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: leftmenu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:36 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:53 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: leftmenu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:53 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:54 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: leftmenu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:54 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:54 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: leftmenu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:28:54 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:29:39 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: leftmenu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:29:39 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:30:27 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: leftmenu ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:30:27 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:31:25 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:31:25 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:31:46 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:31:46 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:01 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:01 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: left ~ APPPATH/views/my_template.php [ 22 ] in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 02:32:02 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/my_template.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#10 {main} in /home/vitas/www/sdsystem/application/views/my_template.php:22
2015-05-19 03:01:18 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:01:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:36 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:37 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:37 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:37 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:38 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:38 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:02:38 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:02:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:03:22 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:03:22 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:03:33 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:03:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:04:09 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-05-19 03:04:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:04:24 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:04:24 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:42 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:42 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:43 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:43 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:43 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:43 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:44 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:05:44 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:06:28 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_ORM' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:06:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:06:41 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:06:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:06:49 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:06:49 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:07:33 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_ORM' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:07:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:08:07 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:08:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:08:08 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:08:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:08:16 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:08:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:08:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_ORM' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:08:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:10:02 --- EMERGENCY: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'ORM' at 'MODPATH/ORM' ~ SYSPATH/classes/Kohana/Core.php [ 579 ] in /home/vitas/www/sdsystem/application/bootstrap.php:132
2015-05-19 03:10:02 --- DEBUG: #0 /home/vitas/www/sdsystem/application/bootstrap.php(132): Kohana_Core::modules(Array)
#1 /home/vitas/www/sdsystem/index.php(102): require('/home/vitas/www...')
#2 {main} in /home/vitas/www/sdsystem/application/bootstrap.php:132
2015-05-19 03:10:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_ORM' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:10:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:10:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_ORM' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:10:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:20:51 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:20:51 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:02 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:02 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:03 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:03 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:04 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:04 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:04 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:21:04 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:23:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_MySQLi' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:23:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:23:22 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:23:22 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:28:57 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:28:57 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:29:13 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:29:13 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:29:20 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:29:20 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:52 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:52 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:30:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:50 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:50 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:52 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:52 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:52 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:52 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:53 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:32:53 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:31 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:31 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:32 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:32 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:32 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:32 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:32 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:36:32 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:37:23 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:37:23 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:37:24 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:37:24 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:37:24 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:37:24 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:38:04 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Mysqli' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:38:04 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:38:19 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:38:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:38:20 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:38:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:38:21 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:38:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:38:39 --- EMERGENCY: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'orm' at 'MODPATH/ORM' ~ SYSPATH/classes/Kohana/Core.php [ 579 ] in /home/vitas/www/sdsystem/application/bootstrap.php:132
2015-05-19 03:38:39 --- DEBUG: #0 /home/vitas/www/sdsystem/application/bootstrap.php(132): Kohana_Core::modules(Array)
#1 /home/vitas/www/sdsystem/index.php(102): require('/home/vitas/www...')
#2 {main} in /home/vitas/www/sdsystem/application/bootstrap.php:132
2015-05-19 03:38:55 --- EMERGENCY: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'orm' at 'MODPATH/Orm' ~ SYSPATH/classes/Kohana/Core.php [ 579 ] in /home/vitas/www/sdsystem/application/bootstrap.php:132
2015-05-19 03:38:55 --- DEBUG: #0 /home/vitas/www/sdsystem/application/bootstrap.php(132): Kohana_Core::modules(Array)
#1 /home/vitas/www/sdsystem/index.php(102): require('/home/vitas/www...')
#2 {main} in /home/vitas/www/sdsystem/application/bootstrap.php:132
2015-05-19 03:39:02 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:39:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:39:03 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:39:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:39:03 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_Orm' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:39:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:39:21 --- EMERGENCY: ErrorException [ 1 ]: Class 'Database_ORM' not found ~ MODPATH/database/classes/Kohana/Database.php [ 78 ] in file:line
2015-05-19 03:39:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 03:40:07 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:40:07 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:10 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:10 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:11 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:12 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:12 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:12 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:12 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:18 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:18 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:18 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:18 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:18 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:18 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:25 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:25 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:25 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:42:25 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(1)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item', 1)
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:43:18 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:43:18 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:39 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:39 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:41 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:41 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:42 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:42 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:46 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:46 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:56 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:56 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:57 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:57 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:57 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:44:57 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:45:04 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: item ~ APPPATH/classes/Controller/Main.php [ 12 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:12
2015-05-19 03:45:04 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(12): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 12, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:12
2015-05-19 03:45:33 --- EMERGENCY: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 67 ] in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 03:45:33 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(171): Kohana_Database_MySQL->connect()
#1 /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1668): Kohana_Database_MySQL->list_columns('items')
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(444): Kohana_ORM->list_columns()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(389): Kohana_ORM->reload_columns()
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(254): Kohana_ORM->_initialize()
#6 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(46): Kohana_ORM->__construct(NULL)
#7 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(7): Kohana_ORM::factory('Item')
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(118): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/modules/database/classes/Kohana/Database/MySQL.php:171
2015-05-19 06:10:55 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/Controller/Main.php [ 16 ] in file:line
2015-05-19 06:10:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:11:22 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 17 ] in file:line
2015-05-19 06:11:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:16:00 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ')' ~ APPPATH/classes/Controller/Main.php [ 19 ] in file:line
2015-05-19 06:16:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:16:38 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:16:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:19:27 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:19:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:21:09 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 34 ] in file:line
2015-05-19 06:21:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:21:10 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 34 ] in file:line
2015-05-19 06:21:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:23:35 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:23:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:23:36 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:23:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:23:37 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:23:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:23:55 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:23:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:23:55 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-05-19 06:23:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:35:47 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected 'foreach' (T_FOREACH), expecting ')' ~ APPPATH/classes/Controller/Main.php [ 19 ] in file:line
2015-05-19 06:35:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:36:01 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected 'foreach' (T_FOREACH), expecting ')' ~ APPPATH/classes/Controller/Main.php [ 19 ] in file:line
2015-05-19 06:36:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 06:38:56 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ',' ~ APPPATH/classes/Controller/Main.php [ 32 ] in file:line
2015-05-19 06:38:56 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 07:16:45 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ')' ~ APPPATH/classes/Controller/Php.php [ 16 ] in file:line
2015-05-19 07:16:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 07:16:50 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ')' ~ APPPATH/classes/Controller/Php.php [ 16 ] in file:line
2015-05-19 07:16:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 10:41:51 --- EMERGENCY: ErrorException [ 1 ]: Class 'Editor' not found ~ APPPATH/classes/Controller/Php.php [ 14 ] in file:line
2015-05-19 10:41:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 10:42:58 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected 'use' (T_USE) ~ APPPATH/classes/Controller/Php.php [ 16 ] in file:line
2015-05-19 10:42:58 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 10:44:30 --- EMERGENCY: ErrorException [ 2 ]: include(../../php/DataTables.php): failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/Controller/Php.php [ 3 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:3
2015-05-19 10:44:30 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(3): Kohana_Core::error_handler(2, 'include(../../p...', '/home/vitas/www...', 3, Array)
#1 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(3): include()
#2 /home/vitas/www/sdsystem/system/classes/Kohana/Core.php(511): require('/home/vitas/www...')
#3 [internal function]: Kohana_Core::auto_load('Controller_Php')
#4 [internal function]: spl_autoload_call('Controller_Php')
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(74): class_exists('Controller_Php')
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(135): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:3
2015-05-19 10:44:43 --- EMERGENCY: ErrorException [ 2 ]: include(../../php/DataTables.php): failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/Controller/Php.php [ 3 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:3
2015-05-19 10:44:43 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(3): Kohana_Core::error_handler(2, 'include(../../p...', '/home/vitas/www...', 3, Array)
#1 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(3): include()
#2 /home/vitas/www/sdsystem/system/classes/Kohana/Core.php(511): require('/home/vitas/www...')
#3 [internal function]: Kohana_Core::auto_load('Controller_Php')
#4 [internal function]: spl_autoload_call('Controller_Php')
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(74): class_exists('Controller_Php')
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(135): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:3
2015-05-19 10:48:17 --- EMERGENCY: ErrorException [ 2 ]: include(../../php/DataTables.php): failed to open stream: Нет такого файла или каталога ~ APPPATH/classes/Controller/Php.php [ 4 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:4
2015-05-19 10:48:17 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(4): Kohana_Core::error_handler(2, 'include(../../p...', '/home/vitas/www...', 4, Array)
#1 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(4): include()
#2 /home/vitas/www/sdsystem/system/classes/Kohana/Core.php(511): require('/home/vitas/www...')
#3 [internal function]: Kohana_Core::auto_load('Controller_Php')
#4 [internal function]: spl_autoload_call('Controller_Php')
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(74): class_exists('Controller_Php')
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(136): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:4
2015-05-19 10:53:43 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR) ~ APPPATH/classes/Controller/Php.php [ 21 ] in file:line
2015-05-19 10:53:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:06:04 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: db ~ APPPATH/classes/Controller/Php.php [ 23 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:23
2015-05-19 11:06:04 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(23): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 23, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:23
2015-05-19 11:06:38 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected 'include' (T_INCLUDE), expecting function (T_FUNCTION) ~ APPPATH/classes/Controller/Php.php [ 5 ] in file:line
2015-05-19 11:06:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:07:00 --- EMERGENCY: ErrorException [ 1 ]: Controller_Php cannot use DataTables\Editor - it is not a trait ~ APPPATH/classes/Controller/Php.php [ 9 ] in file:line
2015-05-19 11:07:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:07:24 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: db ~ APPPATH/classes/Controller/Php.php [ 23 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:23
2015-05-19 11:07:24 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(23): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 23, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:23
2015-05-19 11:10:06 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: db ~ APPPATH/classes/Controller/Php.php [ 22 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:22
2015-05-19 11:10:06 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:22
2015-05-19 11:10:08 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: db ~ APPPATH/classes/Controller/Php.php [ 22 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:22
2015-05-19 11:10:08 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:22
2015-05-19 11:13:34 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: db ~ APPPATH/classes/Controller/Php.php [ 22 ] in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:22
2015-05-19 11:13:34 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 22, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Php.php:22
2015-05-19 11:14:34 --- EMERGENCY: ErrorException [ 8 ]: Constant datatables already defined ~ DOCROOT/editor/php/DataTables.php [ 13 ] in file:line
2015-05-19 11:14:34 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Constant datata...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/editor/php/DataTables.php(13): define('DATATABLES', true, true)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): include('/home/vitas/www...')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in file:line
2015-05-19 11:15:27 --- EMERGENCY: ErrorException [ 8 ]: Constant datatables already defined ~ DOCROOT/editor/php/DataTables.php [ 13 ] in file:line
2015-05-19 11:15:27 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Constant datata...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/editor/php/DataTables.php(13): define('DATATABLES', true, true)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): include('/home/vitas/www...')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in file:line
2015-05-19 11:15:28 --- EMERGENCY: ErrorException [ 8 ]: Constant datatables already defined ~ DOCROOT/editor/php/DataTables.php [ 13 ] in file:line
2015-05-19 11:15:28 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Constant datata...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/editor/php/DataTables.php(13): define('DATATABLES', true, true)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): include('/home/vitas/www...')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in file:line
2015-05-19 11:15:28 --- EMERGENCY: ErrorException [ 8 ]: Constant datatables already defined ~ DOCROOT/editor/php/DataTables.php [ 13 ] in file:line
2015-05-19 11:15:28 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(8, 'Constant datata...', '/home/vitas/www...', 13, Array)
#1 /home/vitas/www/sdsystem/editor/php/DataTables.php(13): define('DATATABLES', true, true)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Php.php(22): include('/home/vitas/www...')
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Php->action_staff()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Php))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in file:line
2015-05-19 11:26:14 --- EMERGENCY: ErrorException [ 1 ]: Class 'Editor' not found ~ APPPATH/classes/Controller/Php.php [ 29 ] in file:line
2015-05-19 11:26:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:26:17 --- EMERGENCY: ErrorException [ 1 ]: Class 'Editor' not found ~ APPPATH/classes/Controller/Php.php [ 29 ] in file:line
2015-05-19 11:26:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:37:53 --- EMERGENCY: ErrorException [ 1 ]: Class 'DataTables\Editor' not found ~ APPPATH/classes/Controller/Staff.php [ 20 ] in file:line
2015-05-19 11:37:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:41:31 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR) ~ APPPATH/classes/Controller/Staff.php [ 32 ] in file:line
2015-05-19 11:41:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-05-19 11:42:11 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR) ~ APPPATH/classes/Controller/Staff.php [ 32 ] in file:line
2015-05-19 11:42:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line