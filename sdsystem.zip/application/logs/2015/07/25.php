<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-07-25 04:02:51 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:02:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:25 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:26 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:26 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:27 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:27 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:29 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:29 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:39 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:39 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:40 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:58 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:58 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:58 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:58 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:04:59 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:04:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:05:47 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:05:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:05:47 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:05:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:01 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:01 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:02 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:08 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:08 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:08 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:42 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:43 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:43 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:43 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:43 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:06:59 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:06:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:07:00 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:07:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:07:00 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:07:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:07:00 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:07:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:07:15 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:07:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:07:45 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_item' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:07:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:08:00 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_items' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:08:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:08:44 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_items' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:08:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:08:45 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_items' not found ~ MODPATH/orm/classes/Kohana/ORM.php [ 46 ] in file:line
2015-07-25 04:08:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 04:08:52 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: models ~ APPPATH/views/main.php [ 32 ] in /home/vitas/www/sdsystem/application/views/main.php:32
2015-07-25 04:08:52 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/main.php(32): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 32, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(236): Kohana_View->render()
#4 /home/vitas/www/sdsystem/application/views/my_template.php(32): Kohana_View->__toString()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#6 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/application/views/main.php:32
2015-07-25 04:08:52 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: models ~ APPPATH/views/main.php [ 32 ] in /home/vitas/www/sdsystem/application/views/main.php:32
2015-07-25 04:08:52 --- DEBUG: #0 /home/vitas/www/sdsystem/application/views/main.php(32): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 32, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#2 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#3 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(236): Kohana_View->render()
#4 /home/vitas/www/sdsystem/application/views/my_template.php(32): Kohana_View->__toString()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(62): include('/home/vitas/www...')
#6 /home/vitas/www/sdsystem/system/classes/Kohana/View.php(359): Kohana_View::capture('/home/vitas/www...', Array)
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Controller/Template.php(44): Kohana_View->render()
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#14 {main} in /home/vitas/www/sdsystem/application/views/main.php:32
2015-07-25 06:16:08 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Item' not found ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 06:16:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:16:27 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Item' not found ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 06:16:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:16:34 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Item' not found ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 06:16:34 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:16:35 --- EMERGENCY: ErrorException [ 1 ]: Class 'Model_Item' not found ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 06:16:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:28:18 --- EMERGENCY: ErrorException [ 2 ]: json_decode() expects parameter 1 to be string, array given ~ APPPATH/classes/Controller/Main.php [ 35 ] in file:line
2015-07-25 06:28:18 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'json_decode() e...', '/home/vitas/www...', 35, Array)
#1 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(35): json_decode(Array)
#2 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_staff()
#3 [internal function]: Kohana_Controller->execute()
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#8 {main} in file:line
2015-07-25 06:33:05 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:33:27 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:33:29 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:29 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:33:48 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:33:49 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:33:50 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 06:33:51 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ']' ~ APPPATH/classes/Controller/Main.php [ 56 ] in file:line
2015-07-25 06:33:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 12:45:50 --- EMERGENCY: ErrorException [ 4096 ]: Argument 3 passed to Kohana_Validation::rule() must be of the type array, string given, called in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php on line 242 and defined ~ SYSPATH/classes/Kohana/Validation.php [ 211 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:45:50 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(211): Kohana_Core::error_handler(4096, 'Argument 3 pass...', '/home/vitas/www...', 211, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(242): Kohana_Validation->rule('name', 'n', 'o')
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(410): Kohana_Validation->rules('name', Array)
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1269): Kohana_ORM->_validation()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#6 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#12 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#13 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:47:01 --- EMERGENCY: ErrorException [ 4096 ]: Argument 3 passed to Kohana_Validation::rule() must be of the type array, string given, called in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php on line 242 and defined ~ SYSPATH/classes/Kohana/Validation.php [ 211 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:47:01 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(211): Kohana_Core::error_handler(4096, 'Argument 3 pass...', '/home/vitas/www...', 211, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(242): Kohana_Validation->rule('name', 'n', 'o')
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(410): Kohana_Validation->rules('name', Array)
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1269): Kohana_ORM->_validation()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#6 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#12 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#13 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:49:05 --- EMERGENCY: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH/orm/classes/Kohana/ORM.php [ 1275 ] in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php:1302
2015-07-25 12:49:05 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#1 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php:1302
2015-07-25 12:49:41 --- EMERGENCY: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH/orm/classes/Kohana/ORM.php [ 1275 ] in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php:1302
2015-07-25 12:49:41 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#1 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php:1302
2015-07-25 12:49:57 --- EMERGENCY: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH/orm/classes/Kohana/ORM.php [ 1275 ] in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php:1302
2015-07-25 12:49:57 --- DEBUG: #0 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#1 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#2 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#4 [internal function]: Kohana_Controller->execute()
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#9 {main} in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php:1302
2015-07-25 12:50:40 --- EMERGENCY: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php on line 410 and defined ~ SYSPATH/classes/Kohana/Validation.php [ 238 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:238
2015-07-25 12:50:40 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(238): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/home/vitas/www...', 238, Array)
#1 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(410): Kohana_Validation->rules('name', 'not_empty')
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1269): Kohana_ORM->_validation()
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#5 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#6 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#7 [internal function]: Kohana_Controller->execute()
#8 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#9 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#11 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#12 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:238
2015-07-25 12:51:27 --- EMERGENCY: ErrorException [ 4096 ]: Argument 3 passed to Kohana_Validation::rule() must be of the type array, string given, called in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php on line 242 and defined ~ SYSPATH/classes/Kohana/Validation.php [ 211 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:51:27 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(211): Kohana_Core::error_handler(4096, 'Argument 3 pass...', '/home/vitas/www...', 211, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(242): Kohana_Validation->rule('name', 'n', 'o')
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(410): Kohana_Validation->rules('name', Array)
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1269): Kohana_ORM->_validation()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#6 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#12 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#13 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:52:22 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '=>' (T_DOUBLE_ARROW) ~ APPPATH/classes/Model/item.php [ 8 ] in file:line
2015-07-25 12:52:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 12:52:25 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '=>' (T_DOUBLE_ARROW) ~ APPPATH/classes/Model/item.php [ 8 ] in file:line
2015-07-25 12:52:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 12:52:59 --- EMERGENCY: ErrorException [ 4096 ]: Argument 3 passed to Kohana_Validation::rule() must be of the type array, string given, called in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php on line 242 and defined ~ SYSPATH/classes/Kohana/Validation.php [ 211 ] in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 12:52:59 --- DEBUG: #0 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(211): Kohana_Core::error_handler(4096, 'Argument 3 pass...', '/home/vitas/www...', 211, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php(242): Kohana_Validation->rule('name', 'n', 'o')
#2 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(410): Kohana_Validation->rules('name', Array)
#3 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1269): Kohana_ORM->_validation()
#4 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1302): Kohana_ORM->check(NULL)
#5 /home/vitas/www/sdsystem/modules/orm/classes/Kohana/ORM.php(1421): Kohana_ORM->create(NULL)
#6 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(52): Kohana_ORM->save()
#7 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#8 [internal function]: Kohana_Controller->execute()
#9 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#10 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#12 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#13 {main} in /home/vitas/www/sdsystem/system/classes/Kohana/Validation.php:211
2015-07-25 13:02:25 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ',' ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 13:02:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 13:02:28 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ',' ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 13:02:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-25 13:02:57 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected ',' ~ APPPATH/classes/Controller/Main.php [ 41 ] in file:line
2015-07-25 13:02:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line