<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-07-26 03:52:35 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:35 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:37 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:37 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:38 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:38 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:38 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:38 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:38 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:38 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:53 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:53 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:56 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:52:56 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:53:10 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/Controller/Main.php [ 55 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 03:53:10 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(55): Kohana_Core::error_handler(8, 'Undefined offse...', '/home/vitas/www...', 55, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_create()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:55
2015-07-26 06:45:09 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected '=>' (T_DOUBLE_ARROW) ~ APPPATH/classes/Controller/Main.php [ 80 ] in file:line
2015-07-26 06:45:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-26 07:04:42 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH/classes/Controller/Main.php [ 121 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:121
2015-07-26 07:04:42 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(121): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 121, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:121
2015-07-26 07:04:48 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH/classes/Controller/Main.php [ 121 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:121
2015-07-26 07:04:48 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(121): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/vitas/www...', 121, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:121
2015-07-26 07:05:13 --- EMERGENCY: ErrorException [ 2 ]: Missing argument 1 for Controller_Main::action_delete(), called in /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php on line 84 and defined ~ APPPATH/classes/Controller/Main.php [ 119 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:119
2015-07-26 07:05:13 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(119): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/vitas/www...', 119, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:119
2015-07-26 07:05:23 --- EMERGENCY: ErrorException [ 2 ]: Missing argument 1 for Controller_Main::action_delete(), called in /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php on line 84 and defined ~ APPPATH/classes/Controller/Main.php [ 119 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:119
2015-07-26 07:05:23 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(119): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/vitas/www...', 119, Array)
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:119
2015-07-26 07:07:23 --- EMERGENCY: Kohana_Exception [ 0 ]: Cannot delete item model because it is not loaded. ~ MODPATH/orm/classes/Kohana/ORM.php [ 1434 ] in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:122
2015-07-26 07:07:23 --- DEBUG: #0 /home/vitas/www/sdsystem/application/classes/Controller/Main.php(122): Kohana_ORM->delete()
#1 /home/vitas/www/sdsystem/system/classes/Kohana/Controller.php(84): Controller_Main->action_delete()
#2 [internal function]: Kohana_Controller->execute()
#3 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Main))
#4 /home/vitas/www/sdsystem/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /home/vitas/www/sdsystem/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /home/vitas/www/sdsystem/index.php(133): Kohana_Request->execute()
#7 {main} in /home/vitas/www/sdsystem/application/classes/Controller/Main.php:122