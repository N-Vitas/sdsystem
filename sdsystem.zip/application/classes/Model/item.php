<?php defined('SYSPATH') or die('No direct script access.');
 
class Model_Item extends ORM {
	protected $_table_name = 'items';
}
