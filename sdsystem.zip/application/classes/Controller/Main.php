<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Main extends Controller_Common {
 
    public function action_index()
    { 
		
		$this->template->positionleft = false;
        // Передаем данные в шаблон по умолчанию - main.php
        $this->template->content = View::factory('main');
    }
    public function action_staff()
    { 
		$item = ORM::factory('item')->find_all();
		foreach($item as $val)
		{	
			$data[] = array(
				"id" => $val->id,
				"name" => $val->name,
				"birthday" => $val->birthday,
				"contact" => $val->contact,
				"state" => $val->state,
				"scool" => $val->scool,
				"job" => $val->job,
				"invalid" => $val->invalid,
				"diagnos" => $val->diagnos,
				"ipr" => $val->ipr,
				"advanset" => $val->advanset,
				"myjob" => $val->myjob,
			);
		}
		$content = array(
		  "data" => $data
		);
		echo json_encode($content);die;
    }
    public function action_create()
    { 
		$model = ORM::factory('item');
		$post = Validation::factory($_POST['data'][0]);
		$post->rule('name'    ,'not_empty')
			 ->rule('birthday','not_empty')
			 ->rule('birthday','not_empty')
			 ->rule('contact' ,'not_empty')
			 ->rule('state'   ,'not_empty')
			 ->rule('scool'   ,'not_empty')
			 ->rule('job'     ,'not_empty')
			 ->rule('invalid' ,'not_empty')
			 ->rule('diagnos' ,'not_empty')
			 ->rule('ipr'     ,'not_empty')
			 ->rule('advanset','not_empty')
			 ->rule('myjob'   ,'not_empty');
		if($post -> check()){
			$model->name	 = $post['name'];	
			$model->birthday = $post['birthday'];		
			$model->contact	 = $post['contact'];	
			$model->state	 = $post['state'];	
			$model->scool	 = $post['scool'];	
			$model->job		 = $post['job'];
			$model->invalid	 = $post['invalid'];	
			$model->diagnos	 = $post['diagnos'];	
			$model->ipr		 = $post['ipr'];
			$model->advanset = $post['advanset'];		
			$model->myjob	 = $post['myjob'];
			if($model->save())
			{
				echo json_encode(["result"=>true]);
			}	
			else{
				echo json_encode(["result"=>false,"errors"=>$model->errors()]);
			}			
		}	
		else{
			echo json_encode(["result"=>false,"errors"=>$post->errors()]);
		}
        die;
    }
    public function action_update()
    { 
		$post = Validation::factory($_POST['data'][0]);
		$post->rule('name'    ,'not_empty')
			 ->rule('birthday','not_empty')
			 ->rule('birthday','not_empty')
			 ->rule('contact' ,'not_empty')
			 ->rule('state'   ,'not_empty')
			 ->rule('scool'   ,'not_empty')
			 ->rule('job'     ,'not_empty')
			 ->rule('invalid' ,'not_empty')
			 ->rule('diagnos' ,'not_empty')
			 ->rule('ipr'     ,'not_empty')
			 ->rule('advanset','not_empty')
			 ->rule('myjob'   ,'not_empty');
		$model = ORM::factory('item')->where("id","=",$post['id'])->find();
		if($post -> check()){
			$model->name	 = $post['name'];	
			$model->birthday = $post['birthday'];		
			$model->contact	 = $post['contact'];	
			$model->state	 = $post['state'];	
			$model->scool	 = $post['scool'];	
			$model->job		 = $post['job'];
			$model->invalid	 = $post['invalid'];	
			$model->diagnos	 = $post['diagnos'];	
			$model->ipr		 = $post['ipr'];
			$model->advanset = $post['advanset'];		
			$model->myjob	 = $post['myjob'];
			if($model->save())
			{
				echo json_encode(["result"=>true]);
			}	
			else{
				echo json_encode(["result"=>false,"errors"=>$model->errors()]);
			}			
		}	
		else{
			echo json_encode(["result"=>false,"errors"=>$post->errors()]);
		}
        die;
    }    
    public function action_delete()
    { 
    	$post = Validation::factory($_POST['data'][0]);
		if(ORM::factory('item',$post['id'])->delete())
		{
			echo json_encode(["result"=>true]);
		}	
		else{
			echo json_encode(["result"=>false]);
		}
        die;
    }
 
} // End Main

