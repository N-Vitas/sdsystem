<pre><?php var_dump($tmp)?></pre>
