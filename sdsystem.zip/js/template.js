var editor; 
function filterColumn ( i ) {
    $('#example').DataTable().column( i ).search(
        $('#col'+i+'_filter').val()
    ).draw();
}
function createData(action,argument) {
    $.ajax({
        type:"POST",
        data:{'data':argument},
        url:"/public/sdsystem/main/"+action,
        dataType:"json"             
        }).done(function (data)
            {                
                if(data.result)
                {
                    $('#example').DataTable().ajax.reload();
                    $(".update, .delete").attr('disabled',true); 
                    $("#dialog").dialog( "close" );
                    //$("#delete").dialog( "close" );
                }
                else
                {
                    data.errors.name ? $("#name").css('border','1px solid red') : $("#name").css('border','1px solid green');
                    data.errors.birthday ? $("#birthday").css('border','1px solid red') : $("#birthday").css('border','1px solid green');
                    data.errors.contact ? $("#contact").css('border','1px solid red') : $("#contact").css('border','1px solid green');
                    data.errors.state ? $("#state").css('border','1px solid red') : $("#state").css('border','1px solid green');
                    data.errors.scool ? $("#scool").css('border','1px solid red') : $("#scool").css('border','1px solid green');
                    data.errors.job ? $("#job").css('border','1px solid red') : $("#job").css('border','1px solid green');
                    data.errors.invalid ? $("#invalid").css('border','1px solid red') : $("#invalid").css('border','1px solid green');
                    data.errors.diagnos ? $("#diagnos").css('border','1px solid red') : $("#diagnos").css('border','1px solid green');
                    data.errors.ipr ? $("#ipr").css('border','1px solid red') : $("#ipr").css('border','1px solid green');
                    data.errors.advanset ? $("#advanset").css('border','1px solid red') : $("#advanset").css('border','1px solid green');
                    data.errors.myjob ? $("#myjob").css('border','1px solid red') : $("#myjob").css('border','1px solid green');
                }                
            });
}
function getDialod(){
    var array = Array({id:$("#id").val(),name:$("#name").val(),birthday:$("#birthday").val(),contact:$("#contact").val(),state:$("#state").val(),scool:$("#scool").val(),job:$("#job").val(),invalid:$("#invalid").val(),diagnos:$("#diagnos").val(),ipr:$("#ipr").val(),advanset:$("#advanset").val(),myjob:$("#myjob").val()});
    return array;
}
$(document).ready(function() {
    $("#birthday").datepicker();
    $("#birthday" ).datepicker( "option", "dateFormat", "yy-mm-dd" );  
    var example = $('#example').DataTable({
        "dom": '<"toolbar">frtip',
        //"dom": 'frtip',
        "ajax": "/public/sdsystem/main/staff",
        "columns": [
            { "data": "id" },
            { "data": "name" },
            { "data": "birthday" },
            { "data": "contact", "render": $.fn.dataTable.render.number( '-' )},
            { "data": "state" },
            { "data": "scool" },
            { "data": "job" },
            { "data": "invalid" },
            { "data": "diagnos" },
            { "data": "ipr" },
            { "data": "advanset" },
            { "data": "myjob" },
        ],
        "scrollY": "300px",
        "scrollX": "100%",
        "scrollCollapse": true,
        "language":{
            "processing": "Подождите...",
            "search": "Поиск:",
            "lengthMenu": "Показать _MENU_ записей",
            "info": "Записи с _START_ до _END_ из _TOTAL_ записей",
            "infoEmpty": "Записи с 0 до 0 из 0 записей",
            "infoFiltered": "(отфильтровано из _MAX_ записей)",
            "infoPostFix": "",
            "loadingRecords": "Загрузка записей...",
            "zeroRecords": "Записи отсутствуют.",
            "emptyTable": "В таблице отсутствуют данные",
            "paginate": {
            "first": "Первая",
            "previous": "Предыдущая",
            "next": "Следующая",
            "last": "Последняя"
            },
            "aria": {
            "sortAscending": ": активировать для сортировки столбца по возрастанию",
            "sortDescending": ": активировать для сортировки столбца по убыванию",
            },
        }
    });
    $("div.toolbar").html("<input type='button' class='create' value='Создать'/><input type='button' class='update' value='Изменить'/><input type='button' class='delete' value='Удалить'/>");
    $('#example tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
            $(".update, .delete").attr('disabled',true);
        }
        else {
            example.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            $(".update, .delete").attr('disabled',false);
        }
    } );
    $(".update, .delete").attr('disabled',true);
    $('input.update').on( 'click', function () {
        var data = $('tr.selected td');
        $("#id").val(      $("#example").dataTable().fnGetData(data[0])).css('border','1px solid green');
        $("#name").val(    $("#example").dataTable().fnGetData(data[1])).css('border','1px solid green');
        $("#birthday").val($("#example").dataTable().fnGetData(data[2])).css('border','1px solid green');
        $("#contact").val( $("#example").dataTable().fnGetData(data[3])).css('border','1px solid green');
        $("#state").val(   $("#example").dataTable().fnGetData(data[4])).css('border','1px solid green');
        $("#scool").val(   $("#example").dataTable().fnGetData(data[5])).css('border','1px solid green');
        $("#job").val(     $("#example").dataTable().fnGetData(data[6])).css('border','1px solid green');
        $("#invalid").val( $("#example").dataTable().fnGetData(data[7])).css('border','1px solid green');
        $("#diagnos").val( $("#example").dataTable().fnGetData(data[8])).css('border','1px solid green');
        $("#ipr").val(     $("#example").dataTable().fnGetData(data[9])).css('border','1px solid green');
        $("#advanset").val($("#example").dataTable().fnGetData(data[10])).css('border','1px solid green');
        $("#myjob").val(   $("#example").dataTable().fnGetData(data[11])).css('border','1px solid green');
        $("#dialog").dialog(
        {
            resizable: false,
            width:600,
            height:550,
            modal: true,
            title:"Изменение записи",
            buttons: {
              "Сохранить": function() {
                createData("update",getDialod());                
              },
              "Отмена": function() {
                $( this ).dialog( "close" );
              }
            }
        }
        )        
    } );
    $('input.create').on( 'click', function () {
        $("#dialog input").val("");
        $("#name").css('border','1px solid grey')
        $("#birthday").css('border','1px solid grey')
        $("#contact").css('border','1px solid grey')
        $("#state").css('border','1px solid grey')
        $("#scool").css('border','1px solid grey')
        $("#job").css('border','1px solid grey')
        $("#invalid").css('border','1px solid grey')
        $("#diagnos").css('border','1px solid grey')
        $("#ipr").css('border','1px solid grey')
        $("#advanset").css('border','1px solid grey')
        $("#myjob").css('border','1px solid grey')
        $("#dialog").dialog(
        {
            resizable: false,
            width:600,
            height:550,
            modal: true,
            title:"Создание записи",
            buttons: {
              "Сохранить": function() {
                createData("create",getDialod());
              },
              "Отмена": function() {
                $( this ).dialog( "close" );
              }
            }
        }
        );
    } );
    $('input.delete').on( 'click', function () {
        $("#dialog input").val("");        
        var data = $('tr.selected td');
        $("#id").val($("#example").dataTable().fnGetData(data[0]));
        $("#delete").dialog(
        {
            resizable: false,
            width:300,
            height:150,
            modal: true,
            title:"Удаление записи",
            buttons: {
              "Удалить": function() {
                createData("delete",getDialod());
                $( this ).dialog( "close" );
              },
              "Отмена": function() {
                $( this ).dialog( "close" );
              }
            }
        }
        );
    } );
    $("#dialog, #delete").hide();
    $('input.column_filter').on( 'keyup click', function () {
        filterColumn( $(this).parents('th').attr('data-column') );
    } );
} );