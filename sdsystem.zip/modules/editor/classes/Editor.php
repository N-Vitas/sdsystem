<?php defined('SYSPATH') OR die('No direct access allowed.');

abstract class Editor extends Kohana_Editor { }
