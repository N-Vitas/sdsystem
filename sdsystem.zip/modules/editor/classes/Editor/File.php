<?php defined('SYSPATH') OR die('No direct access allowed.');

class Editor_File extends Kohana_Editor_File { }
