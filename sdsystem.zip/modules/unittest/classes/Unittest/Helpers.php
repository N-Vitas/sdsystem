<?php defined('SYSPATH') or die('No direct script access.');

class Unittest_Helpers extends Kohana_Unittest_Helpers {}
