<?php

return array
(
	'modules' => array(
		'minion' => array(
			'enabled' => TRUE,
			'name' => 'Minion',
			'description' => 'Minion is a simple command line task runner',
			'copyright' => '&copy; 2009-2011 Kohana Team',
		)
	)
);