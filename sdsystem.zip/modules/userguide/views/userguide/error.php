<h1>Kodoc - <?php echo 'Error'; ?></h1>

<p><?php echo $message ?></p>